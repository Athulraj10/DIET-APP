from tkinter import CASCADE
from django.db import models

# Create your models here.

class Registration(models.Model):
    firstname=models.CharField(max_length=100)
    lastname=models.CharField(max_length=100)
    address=models.CharField(max_length=100)
    gender=models.CharField(max_length=100)
    state=models.CharField(max_length=100)
    dob=models.CharField(max_length=100)
    pincode=models.IntegerField()
    # email=models.EmailField(max_length=100)
    # password=models.CharField(max_length=100)


class Health(models.Model):
    # user_id=models.ForeignKey(to=Registration,on_delete=models.CASCADE)
    arthritis=models.BooleanField()
    pcos=models.BooleanField()
    diabetes=models.BooleanField()
    cholesterol=models.BooleanField()
    thyroid=models.BooleanField()
    stroke=models.BooleanField()
    caldef=models.BooleanField()
    vitdef=models.BooleanField()
    diabetes=models.BooleanField()
    kidneystone=models.BooleanField()


class UserLoginss(models.Model):
    user_id=models.ForeignKey(to=Registration,on_delete=models.CASCADE)
    email=models.EmailField(max_length=100)
    password=models.CharField(max_length=100)



class Bmis(models.Model):
    user_id=models.ForeignKey(to=UserLoginss,on_delete=models.CASCADE)
    heights=models.FloatField(max_length=100)
    weights=models.FloatField(max_length=100)
    bmi=models.FloatField(max_length=100)
    








    

























































    








