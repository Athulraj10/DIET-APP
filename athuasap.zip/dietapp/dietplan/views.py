
from django.http import HttpResponse
from django.shortcuts import render,redirect
from .models import Registration

# Create your views here.
from .models import *

def home(request):
    return render(request,'index.html')

def nav(request):
    return render(request,'nav.html')


def contact(request):
    return render(request,'contact.html')

def service(request):
    return render(request,'service.html')

def cholesterol(request):
    return render(request,'cholesterol.html')


def arthritis(request):
    return render(request,'arthritis.html')

def diabetes(request):
    return render(request,'diabetes.html')

def bp(request):
    return render(request,'bp.html')

def pcos(request):
    return render(request,'pcos.html')

def about(request):
    return render(request,'about.html')

def viewreg(request):
    user=Registration.objects.all()
    return render(request, 'view.html',{'data':user})


def login(request):
    if request.method == 'GET':
        return render(request,'login.html')
    elif request.method =='POST':
        uname=request.POST['uname']
        pswdl = request.POST['pswdl']
        print(uname,pswdl)
        try:
            log=UserLoginss.objects.get(email=uname,password=pswdl)
            print(log)
            if log:
                request.session['logid']=log.id
                request.session['userid']=log.user_id_id
                return redirect('user')
                # return redirect('user')
                # print('me')

        except:
                return render(request,'login.html',{'msg':'couldnt find user !!'})

                # return redirect('user')

                # return redirect('login')
        # return render(request,'user.html',{'msg',"post method worked"})
    # else:
        # return render(request,'user.html',{'msg'},'error')
                # return render(request,'login.html',{'msg':'post method worked'})

def logout(request):
    if 'logid' in request.session:
        del request.session['logid']
        return redirect('home')

    # return render(request,'home.html')     

        


def register(request):
    if request.method=='GET':
        return render(request,'register.html')
    elif request.method=='POST':
        firstname = request.POST['fname']
        lastname = request.POST['lname']
        addres= request.POST['address']
        gndr= request.POST['radio1']
        states=request.POST['state']
        dobs = request.POST['dob']
        pin = request.POST['pincode']
        mail = request.POST['email']
        psswd = request.POST['pswd']
        psswwd = request.POST['cpswd']
        if psswd==psswwd:
            passwd=psswwd
        else:
            return render(request,'register.html')
        print(firstname,lastname,addres,gndr,states,dobs,pin,mail,passwd)
        obj = Registration()
        obj1=UserLoginss()
        obj.firstname = firstname
        obj.lastname = lastname
        obj.address = addres
        obj.gender = gndr
        obj.state = states
        obj.dob = dobs
        obj.pincode = pin
        obj1.email = mail
        obj1.password =passwd
        obj.save()
        obj1.user_id = obj
        obj1.save()
        return redirect('bmi')

def bmi(request):
    
    if request.method=='POST':
        h1=request.POST['heightbmi']
        print(h1)
        h1=float(h1)
        print(type(h1))
        
        h1=h1*0.393701
        w1=request.POST['weightbmi']
        w1=float(w1)
        w1=w1*2.205
        bmi1=(703*h1/(w1*w1))*10
        bmi1=float(bmi1)
        # bmiobj=Bmis()
        # bmiobj.heights=h1
        # bmiobj.weights=w1
        # bmiobj.bmi=bmi1
        # bmi_ob=UserLoginss()
        # bmi_ob.user_id=request.session['logid']
        # bmiobj.user_id=request.session['logid']
        # user = UserLoginss.objects.get(id=request.session['logid'])
        # bmiobj.bmi_id=user.user_id
        # bmi_ob.save()
        # bmiobj.save()
        # data={bmi1}

        # print(bmi1)
        return render(request,'bmi.html',{'data':bmi1})
    else:
        return render(request,'bmi.html')

def health(request):
    if request.method=='GET':
        return render(request,'health.html')
    elif request.method=='POST':
        print('post worked')
        opt = request.POST.get('health', None)
        
        # print(pcos1,glucose,arth,) # get('diabetes', None)
        # data = {}
        if opt == 'none':
            return redirect('pcos')
        elif opt == 'arthritis':
            return redirect('artritis')
        elif opt == 'pcos':
            return redirect('pcos')
        elif opt == 'diabetes':
            return redirect('diabetes')
        elif opt == 'hypertension':
            return redirect('bp')
        elif opt == 'thyroid':
            return redirect('diabetes')
        elif opt == 'cd':
            return redirect('bp')
        elif opt == 'kidneystone':
            return redirect('bp')
        elif opt == 'vd':
            return redirect('bp')
        elif opt == 'stroke':
            return redirect('bp')
        elif opt == 'cholesterol':
            return redirect('bp')
        
def user(request):
    user_id =  request.session['logid']
    user = UserLoginss.objects.get(id=user_id)
    # uid=request.session['userid']
    # bmi=Bmis.objects.get(bmi_id_id=uid)
    print(user)
    return render(request,'user.html',{"user":user,'bmi':bmi})




def payment(request):
    return render(request,'payment.html')     



            
        
        

    # if 'logid' in request.session:
    #     del request.session['log']
    #     return redirect('home')

    # return redirect('home')
        
        
    # else:
    #     return HttpResponse('again')   


            # data['pcos']=Pcos.objects.all()
        

        # return redirect()
            # 
            # chol,bp,thyroid1,stroke1,caldef,ks,vitdef)

            # hlth=Health()
            # hlth.pcos = pcos1
            # hlth.diabetes =  glucose
            # hlth.arthritis = arth
            # hlth.hypertension =  bp
            # hlth.thyroid = thyroid1
            # hlth.stroke = stroke1
            # hlth.cd = caldef
            # hlth.caldef = cd
            # hlth.kidneystone = ks
            # hlth.vd = vitdef
            # hlth.save()
            # return render('bmi')




    # return render(request,'health.html')



