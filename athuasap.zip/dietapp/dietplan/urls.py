from django.contrib import admin
from django.urls import path,include
# from django.urls import path

from .views import *

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('',home,name="home"),
    path('contact/',contact,name="contact"),
    path('about/',about,name="about"),
    path('login/',login,name="login"),
    path('reg/',register,name="register"),
    path('bmi/',bmi,name="bmi"),
    path('health/',health,name="health"),
    path('service/',service,name="service"),
    path('nav/',nav,name="nav"),
    path('user/',user,name="user"),
    path('chol/',cholesterol,name="cholesterol"),
    path('arth/',arthritis,name="artritis"),
    path('diab/',diabetes,name="diabetes"),
    path('bp/',bp,name="bp"),
    path('pcos/',pcos,name="pcos"),
    path('pay/',payment,name="payment"),
    path('view/',viewreg,name='view'),
    path('logout/',logout,name='logout'),



            # return redirect('pcos')






  
]
